// config.js
module.exports = {  
    jwtSecret: "8y9t8s7tWc!",
    jwtSession: {
        session: false
    }
};
